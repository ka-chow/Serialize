package com.mirea.kt.example;
import java.io.Serializable;
import java.util.ArrayList;

public class Product implements Serializable {
    private long code;
    private ArrayList<String>ingredientst = new ArrayList<String>();
    private String name;
    private String type;
    private boolean isDiscount;
    private double price;
    private static final long serialVersionUID = -3536693998646060163L;
    public Product(long code, String name, String type, boolean isDiscount, double price) {
        this.code = code;
        this.name = name;
        this.type = type;
        this.isDiscount = isDiscount;
        this.price = price;
    }

    public Product(ArrayList<String> ingredientst) {
        this.ingredientst = ingredientst;
    }

    public long getCode() {
        return code;
    }

    public void setCode(long code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isDiscount() {
        return isDiscount;
    }

    public void setDiscount(boolean discount) {
        isDiscount = discount;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    @Override
    public String toString(){
        return "code " + this.code+ " name "+ this.name+" type "+this.type+" Discount "+ this.isDiscount+" price "+this.price+" igridients "+this.ingredientst;
    }
}
