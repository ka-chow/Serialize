package com.mirea.kt.example;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Scanner;

public class ProductRunnable implements Runnable{

    Scanner scan = new Scanner(System.in);
    String path = scan.nextLine();
    @Override
    public void run(){
        FileInputStream fis;
        try{
            fis = new FileInputStream(path);
            ObjectInputStream ois = new ObjectInputStream(fis);
            Product product = (Product) ois.readObject();
            ois.close();
            System.out.println(product.toString());
        }catch(ClassNotFoundException | IOException ex){
            System.out.println(ex.getMessage());
        }
    }
}
