import com.mirea.kt.example.ProductRunnable;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

//"C:\\Users\\1625207\\Downloads\\product.ser"

public class Main {
    public static void main(String[] args) throws IOException {
        System.out.println("Enter the directory");
        ProductRunnable pr = new ProductRunnable();
        Thread th = new Thread(pr);
        th.start();
        BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\1625207\\Downloads\\product.ser"));
        String str;
        ArrayList<String> ingredientst = new ArrayList<String>();
        while((str = reader.readLine()) != null ){
            if(!str.isEmpty()){
                ingredientst.add(str);
                System.out.println(ingredientst);
            }}
    }
}